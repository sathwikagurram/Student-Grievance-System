const filterbtn = document.getElementById("filterbtn");
const filterform = document.getElementById("filterform");
filterbtn.addEventListner("click", () => {
        filterform.submit();
})