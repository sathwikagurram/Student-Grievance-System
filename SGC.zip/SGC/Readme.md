## SGC  - Nodejs & Mongodb

### SGC created for hackathon conducted by it deptartment